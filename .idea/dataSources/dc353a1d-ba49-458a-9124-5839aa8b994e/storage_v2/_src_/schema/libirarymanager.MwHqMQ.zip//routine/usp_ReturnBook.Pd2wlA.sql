create
    definer = LibiraryManager@`%` procedure usp_ReturnBook(IN BorrowDetailId int, IN ReturnCount int, IN AdminName_R varchar(20))
BEGIN
/* BorrowDetailId 借书编号  ReturnCount 还书数量  AdminName_R 还书管理员*/
/*声明一个变量，标识是否有sql异常*/
DECLARE
	hasSqlError INT DEFAULT FALSE;
/*在执行过程中出任何异常设置hasSqlError为TRUE*/
DECLARE
CONTINUE HANDLER FOR SQLEXCEPTION 
	SET hasSqlError = TRUE;
/*开启事务*/
START TRANSACTION;-- 插入还书数据
INSERT INTO ReturnBook ( BorrowDetailId, ReturnCount, AdminName_R ,ReturnDate)
VALUES
	( BorrowDetailId, ReturnCount, AdminName_R,NOW() );-- 更新还书总数 、未还书总数
UPDATE BorrowDetail 
SET BorrowDetail.ReturnCount = BorrowDetail.ReturnCount + ReturnCount,
NonReturnCount = BorrowDetail.NonReturnCount  - ReturnCount 
WHERE
	BorrowDetail.BorrowDetailId = BorrowDetailId;
	
	/*根据hasSqlError判断是否有异常，做回滚和提交操作*/
    IF hasSqlError THEN
      ROLLBACK;
    ELSE
      COMMIT;
    END IF;

END;

