create definer = LibiraryManager@`%` view view_QueryReader as
select `libirarymanager`.`Readers`.`ReadingCard`     AS `ReadingCard`,
       `libirarymanager`.`Readers`.`ReaderName`      AS `ReaderName`,
       `libirarymanager`.`ReaderRoles`.`RoleName`    AS `RoleName`,
       `libirarymanager`.`ReaderRoles`.`AllowDay`    AS `AllowDay`,
       `libirarymanager`.`ReaderRoles`.`AllowCounts` AS `AllowCounts`,
       `libirarymanager`.`Readers`.`ReaderImage`     AS `ReaderImage`,
       `libirarymanager`.`Readers`.`PostCode`        AS `PostCode`,
       `libirarymanager`.`Readers`.`ReaderId`        AS `ReaderId`,
       `libirarymanager`.`Readers`.`StatusId`        AS `StatusId`,
       `libirarymanager`.`Readers`.`PhoneNumber`     AS `PhoneNumber`,
       `libirarymanager`.`Readers`.`ReaderAddress`   AS `ReaderAddress`,
       `libirarymanager`.`Readers`.`IDCard`          AS `IDCard`,
       `libirarymanager`.`Readers`.`Gender`          AS `Gender`
from (`libirarymanager`.`Readers`
         join `libirarymanager`.`ReaderRoles`
              on ((`libirarymanager`.`Readers`.`RoleId` = `libirarymanager`.`ReaderRoles`.`RoleId`)));

