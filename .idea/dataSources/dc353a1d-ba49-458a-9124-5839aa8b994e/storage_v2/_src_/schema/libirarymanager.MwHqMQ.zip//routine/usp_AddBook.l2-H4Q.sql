create
    definer = LibiraryManager@`%` procedure usp_AddBook(IN BarCode varchar(20), IN BookName varchar(100),
                                                        IN Author varchar(50), IN PublisherId int,
                                                        IN PublishDate datetime, IN BookCategory int,
                                                        IN UnitPrice decimal(18, 2), IN BookImage text,
                                                        IN BookCount int, IN Remainder int, IN BookPosition varchar(20))
BEGIN
	insert into Books(BarCode,BookName,Author,PublisherId,PublishDate,BookCategory,
				UnitPrice,BookCount,Remainder,BookPosition,BookImage,RegTime)
		values(BarCode,BookName,Author,PublisherId,PublishDate,BookCategory,
				UnitPrice,BookCount,Remainder,BookPosition,BookImage,NOW());

END;

