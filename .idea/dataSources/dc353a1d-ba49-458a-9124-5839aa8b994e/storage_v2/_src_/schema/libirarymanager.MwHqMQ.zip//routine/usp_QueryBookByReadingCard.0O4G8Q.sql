create
    definer = LibiraryManager@`%` procedure usp_QueryBookByReadingCard(IN ReadingCard varchar(20))
BEGIN
	select ReadingCard,BorrowDetailId,BorrowDetail.BorrowId,BorrowDetail.BookId,BookName,
		BarCode,BorrowCount,ReturnCount,NonReturnCount,BorrowDate,Expire,
		 CASE
		when NOW()>Expire then '已过期'
		when  NOW()<Expire then '借阅期内'
		end StatusDesc
		from BorrowDetail
		inner join BorrowInfo on BorrowInfo.BorrowId=BorrowDetail.BorrowId
		inner join Readers on BorrowInfo.ReaderId=Readers.ReaderId
		inner join Books on Books.BookId=BorrowDetail.BookId
		where NonReturnCount>0	and Readers.ReadingCard=ReadingCard
		order by BookName,BorrowDate ASC;
END;

