create
    definer = LibiraryManager@`%` procedure usp_QueryBorrowCount(IN ReadingCard varchar(20))
BEGIN

SELECT	SUM( NonReturnCount )
FROM
	BorrowDetail
	INNER JOIN BorrowInfo ON BorrowInfo.BorrowId = BorrowDetail.BorrowId
	INNER JOIN Readers ON BorrowInfo.ReaderId = Readers.ReaderId 
WHERE
	NonReturnCount > 0 
	AND Readers.ReadingCard = ReadingCard;


END;

