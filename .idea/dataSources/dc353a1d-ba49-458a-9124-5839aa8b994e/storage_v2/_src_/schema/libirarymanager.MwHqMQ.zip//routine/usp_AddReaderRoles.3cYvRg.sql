create
    definer = LibiraryManager@`%` procedure usp_AddReaderRoles(IN RoleName varchar(20), IN AllowDay int, IN AllowCounts int)
BEGIN
	insert into ReaderRoles(RoleName, AllowDay, AllowCounts)
	values(RoleName, AllowDay, AllowCounts);
	END;

