create
    definer = LibiraryManager@`%` procedure usp_EditBook(IN BookId int, IN BookName varchar(100),
                                                         IN BarCode varchar(50), IN Author varchar(50),
                                                         IN PublisherId int, IN PublishDate datetime,
                                                         IN BookCategory int, IN UnitPrice decimal(18, 2),
                                                         IN BookImage text, IN BookCount int,
                                                         IN BookPosition varchar(20))
BEGIN

	update  Books set Books.BarCode=BarCode,Books.BookName=BookName,Books.Author=Author,Books.PublisherId=PublisherId,
				  Books.PublishDate=PublishDate,Books.BookCategory=BookCategory,Books.UnitPrice=UnitPrice,
				  Books.BookCount=BookCount,Books.BookPosition=BookPosition,Books.BookImage=BookImage 
				  where Books.BookId=BookId;
	END;

